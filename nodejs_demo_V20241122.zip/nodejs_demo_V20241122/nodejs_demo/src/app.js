const express = require('express')
const path = require('path')
var cookieParser = require("cookie-parser")
var session = require("express-session")
const app = express()
const UserController = require('./controllers/user') 
const { UserModel } = require('./models')
var debug = require("debug")("index.js");

app.use(express.json())
app.use(express.urlencoded(({ extended: false })))
app.set('view engine', 'pug')
app.set('views', path.join(__dirname, 'views'))


app.use('/static', express.static(path.join(__dirname, 'public')))
app.use('/users', UserController)
app.use(cookieParser())
app.use(
  session({
    secret: "demoapp",
    name: "app",
    resave: true,
    saveUninitialized: true,
    // cookie: { maxAge: 10000 } /* 6000 ms? 6 seconds -> wut? :S */
  })
);
const checkLoggedIn = function(req, res, next) {
  if (req.session.loggedIn) {
    debug(
      "checkLoggedIn(), req.session.loggedIn:",
      req.session.loggedIn,
      "executing next()"
    );
    next();
  } else {
    debug(
      "checkLoggedIn(), req.session.loggedIn:",
      req.session.loggedIn,
      "rendering login"
    );
    res.redirect("login");
  }
}


app.get('/', checkLoggedIn, async function (req, res) {
  // res.sendFile(path.join(__dirname,'index.html'))
  const allUsers = await UserModel.getAllUsers() 
  console.log(allUsers)
  res.render('index', { data: allUsers || [] })

})

app.post('/login', async function(req, res) {
  const { username, password } = req.body     
    try {
        const user = await UserModel.findUserByUsername(username)
        // FAIL-FAST 
        console.log({ user });
        
        if(!user || user.username !== username || user.password !== password) throw new Error('Unauthorized access')
        req.session.loggedIn = true
        res.redirect('/')
    }
    catch(error) {
      console.error(error)
      res.render('login', { error: error.message })
    }
})

app.get('/login', function(req, res) {
  if(req.session.loggedIn) res.redirect('/')
  res.render('login')
})

app.listen(3000, function () {
    console.log('Example app listening on port 3000!')
})