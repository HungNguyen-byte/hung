const UserModel = require('./user.mongo')
module.exports = {
    UserModel
}