const { name } = require("ejs");
const mongoose = require("mongoose");
const connect = mongoose.Connect("mongodb://localhost:27017/demo_first_app");

//check database connected or not
connect.then(() =>  {
     console.log("Database connected Successfully");
})
.catch(() => {
    console.log("Database cannot be connected");
})

//Create a schema
const LoginShema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
})

//collection Part
const collection = new mongoose.model("users", LoginShema);
module.exports = collection;
